
-- --------------------------------------------------------

--
-- Estrutura da tabela `lista_loja_games`
--

CREATE TABLE `lista_loja_games` (
  `id_jogo` int(11) NOT NULL,
  `nome_loja` varchar(255) NOT NULL,
  `link_loja` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
