
-- --------------------------------------------------------

--
-- Estrutura da tabela `adms`
--

CREATE TABLE `adms` (
  `id_adm` int(11) NOT NULL,
  `nome_adm` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `ativo` tinyint(1) NOT NULL,
  `CPF` varchar(255) NOT NULL,
  `RG` int(11) NOT NULL,
  `estado` varchar(255) NOT NULL,
  `cidade` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `adms`
--

INSERT INTO `adms` (`id_adm`, `nome_adm`, `email`, `senha`, `ativo`, `CPF`, `RG`, `estado`, `cidade`) VALUES
(1, 'Luis Francisco Brum Gomes', 'luisfrancisco.15.brum@gmail.com', '$2y$10$YdeDbsuevFWIsBlJFqlLveR/L3PaGdqyAMw.9I7u2vmKgPm4Jknj.', 1, '01888847000', 1853153985, 'Rio Grande do Sul', 'Uruguaiana');
