
-- --------------------------------------------------------

--
-- Estrutura da tabela `jogos_possui`
--

CREATE TABLE `jogos_possui` (
  `id_user` int(11) NOT NULL,
  `id_game` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `jogos_possui`
--

INSERT INTO `jogos_possui` (`id_user`, `id_game`) VALUES
(9, 1),
(9, 4),
(8, 2),
(8, 4),
(8, 17);
