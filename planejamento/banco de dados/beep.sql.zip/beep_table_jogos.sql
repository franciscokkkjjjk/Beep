
-- --------------------------------------------------------

--
-- Estrutura da tabela `jogos`
--

CREATE TABLE `jogos` (
  `id_jogos` int(11) NOT NULL,
  `nome_jogo` varchar(255) NOT NULL,
  `img_jogo` varchar(255) NOT NULL,
  `desc_jogo` text NOT NULL,
  `loja` varchar(255) NOT NULL,
  `link_loja` text DEFAULT NULL,
  `class_etaria` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `jogos`
--

INSERT INTO `jogos` (`id_jogos`, `nome_jogo`, `img_jogo`, `desc_jogo`, `loja`, `link_loja`, `class_etaria`) VALUES
(1, 'red dead redemption 2', 'r.png', 'Red Dead Redemption 2 é um jogo de faroeste de ação-aventura ambientado em um mundo aberto e jogado a partir de uma perspectiva de terceira e primeira pessoa, com componentes de singleplayer e multiplayer online. O jogo tem novas opções, ausentes no jogo anterior.', 'steam', '', 18),
(2, 'red dead redemption 2', 'r.png', 'Red Dead Redemption 2 é um jogo de faroeste de ação-aventura ambientado em um mundo aberto e jogado a partir de uma perspectiva de terceira e primeira pessoa, com componentes de singleplayer e multiplayer online. O jogo tem novas opções, ausentes no jogo anterior.', 'steam', '', 18),
(3, 'red dead redemption 2', 'r.png', 'Red Dead Redemption 2 é um jogo de faroeste de ação-aventura ambientado em um mundo aberto e jogado a partir de uma perspectiva de terceira e primeira pessoa, com componentes de singleplayer e multiplayer online. O jogo tem novas opções, ausentes no jogo anterior.', 'steam', '', 18),
(4, 'red dead redemption 2', 'r.png', 'Red Dead Redemption 2 é um jogo de faroeste de ação-aventura ambientado em um mundo aberto e jogado a partir de uma perspectiva de terceira e primeira pessoa, com componentes de singleplayer e multiplayer online. O jogo tem novas opções, ausentes no jogo anterior.', 'steam', '', 18),
(5, 'red dead redemption 2', 'r.png', 'Red Dead Redemption 2 é um jogo de faroeste de ação-aventura ambientado em um mundo aberto e jogado a partir de uma perspectiva de terceira e primeira pessoa, com componentes de singleplayer e multiplayer online. O jogo tem novas opções, ausentes no jogo anterior.', 'steam', '', 18),
(6, 'red dead redemption 2', 'r.png', 'Red Dead Redemption 2 é um jogo de faroeste de ação-aventura ambientado em um mundo aberto e jogado a partir de uma perspectiva de terceira e primeira pessoa, com componentes de singleplayer e multiplayer online. O jogo tem novas opções, ausentes no jogo anterior.', 'steam', '', 18),
(7, 'red dead redemption 2', 'r.png', 'Red Dead Redemption 2 é um jogo de faroeste de ação-aventura ambientado em um mundo aberto e jogado a partir de uma perspectiva de terceira e primeira pessoa, com componentes de singleplayer e multiplayer online. O jogo tem novas opções, ausentes no jogo anterior.', 'steam', '', 18),
(17, 'ben 10 força', 'ef1737938cf4b5fc810c42320e5f98cd4b0fbf88.jpeg', 'é um baita jogo', 'steam ', 'www.google.com', 18),
(18, '?????? ?', '6d367f298e3cc8ed86412d4edaa81701c23b1dc8.jpeg', 'dsasda', 'dasdsa', 'sdadsa', 18),
(19, 'ççççç é', '6d367f298e3cc8ed86412d4edaa81701c23b1dc8.jpeg', 'dsasda', 'dasdsa', 'sdadsa', 18),
(20, 'ççççç é', '6d367f298e3cc8ed86412d4edaa81701c23b1dc8.jpeg', 'dsasda', 'dasdsa', 'sdadsa', 18),
(21, 'pedrinha games', 'daefee359a9cca654b509b0a0058899fa010237f.jpeg', 'kkkkkkkkkkkkkkkkk\r\n\r\n\r\n\r\n\r\npqp nem faz sentido isso', 'steam ', 'https://mail.google.com/mail/u/0/#inbox', 10);
