
-- --------------------------------------------------------

--
-- Estrutura da tabela `curtidas`
--

CREATE TABLE `curtidas` (
  `id_user_curti` int(11) NOT NULL,
  `id_postagem` int(11) NOT NULL,
  `curtida_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `curtidas`
--

INSERT INTO `curtidas` (`id_user_curti`, `id_postagem`, `curtida_date`) VALUES
(8, 439, '2022-09-14 22:50:18'),
(8, 816, '2022-09-30 15:00:32'),
(9, 828, '2022-10-04 21:36:51'),
(9, 828, '2022-10-04 21:36:51'),
(8, 841, '2022-10-16 15:13:28');
