
-- --------------------------------------------------------

--
-- Estrutura da tabela `seguidores`
--

CREATE TABLE `seguidores` (
  `user_seguin` int(11) NOT NULL,
  `user_seguido` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `seguidores`
--

INSERT INTO `seguidores` (`user_seguin`, `user_seguido`) VALUES
(8, 8),
(22, 22),
(22, 8),
(23, 23),
(23, 9),
(23, 22),
(23, 8),
(22, 10),
(24, 24),
(9, 24),
(25, 25),
(9, 25),
(26, 26),
(26, 9),
(10, 8),
(27, 27),
(28, 28),
(28, 24),
(29, 29),
(30, 30),
(31, 31),
(22, 9),
(22, 31),
(22, 12),
(22, 24),
(32, 32),
(9, 22),
(9, 8),
(9, 12),
(12, 10),
(9, 10),
(33, 33),
(8, 9),
(8, 10),
(8, 12),
(8, 22),
(9, 32),
(8, 24),
(8, 25),
(34, 34),
(35, 35),
(35, 8),
(36, 36),
(8, 32);
