
-- --------------------------------------------------------

--
-- Estrutura da tabela `solic_list_lojas`
--

CREATE TABLE `solic_list_lojas` (
  `id_soli` int(11) NOT NULL,
  `nome_loja` varchar(255) NOT NULL,
  `link_loja` text NOT NULL,
  `data de expedicao` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
